# Images Folder

Place your images here for use in the portfolio.

## About Me Image

**File location:** `assets/images/about-me.jpg`

**Recommended specifications:**
- Format: JPG or PNG
- Size: At least 600x600 pixels (square image works best)
- The image will be displayed as a circular photo (300x300px on desktop, 200x200px on mobile)
- Make sure the image is well-lit and professional

**Alternative formats accepted:**
- `about-me.png`
- `about-me.jpeg`
- `about-me.webp`

The image will automatically be styled with:
- Circular border
- Cyan accent border
- Hover animation effect
- Responsive sizing for mobile devices

